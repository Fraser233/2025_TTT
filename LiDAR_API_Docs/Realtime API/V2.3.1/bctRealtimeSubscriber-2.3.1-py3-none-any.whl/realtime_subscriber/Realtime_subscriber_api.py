import threading
import time 
import requests
from realtime_subscriber import Realtime_subscriber


class BCTWSConnection(Realtime_subscriber.BCTWSConnection):
    def __init__(self, UDID, username,password, serverAddress=None,beaconAddress="https://realtime.us.beacon.1.api.bluecity.ai/",subscriptions=(Realtime_subscriber.BCTWSConnection.subscriptionOption.FRAME,), cacheSize=400,singleton=False,TLS=True):
        self.username= username
        self.password =password
        self.token=None
        self.createLogger()
        while not self.getToken():
            time.sleep(20)
            self.logger.error("Can not authentication user")

        super().__init__(UDID,self.token,serverAddress,beaconAddress,subscriptions,cacheSize,singleton,TLS)
    
    def getToken(self):
        try:
            res = requests.post("https://core.api.bluecity.ai/api/token/",json={"username":self.username,"password":self.password})
            if res.status_code == 200:
                self.token=res.json()["access"]
                self.refresh  = res.json()["refresh"]
                return True
            else:
                return False
        except:
            return False

    def refreshToken(self):
        try:
            res = requests.post("https://core.api.bluecity.ai/api/token/refresh/",json={"refresh":self.refresh})
            if res.status_code == 200:
                self.token=res.json()["access"]
                return True
            else:
                return False
        except:
            return False
            

    def renewToken(self):
        while True:
            time.sleep(2*60*60)
            if self.refreshToken():
                continue
            else:
                while not self.getToken():
                    time.sleep(5)
                    self.logger.error("Can not authentication user")


    def run(self):
        threading.Thread(target=self.renewToken,daemon=True).start()
        return super().run()
