from realtime_subscriber import realtime_subscriber_pb2_grpc
from realtime_subscriber import Realtime_subscriber
import grpc
import time
import datetime
from realtime_subscriber import header_manipulator_client_interceptor
from coreapi_security.certficiate_handler import iCertificateHandler
from coreapi_security.core_auth_helper import create_auth_header_grpc_skipChallenge
from typing import Union
from base64 import urlsafe_b64decode
import json
import requests

class Sub_serviceAuth_SSC(grpc.AuthMetadataPlugin):
    def __init__(self, udid,header):
        self._udid=udid
        self.header = header + [('bct-udid', self._udid),('type', '5')]

        super().__init__()

    def __call__(self, context, callback):
        callback(self.header, None)




class BCTWSConnection(Realtime_subscriber.BCTWSConnection):
    """
    You can use this class to communicate with realtime api using Service Specific Certificates (SSC)
    """

    def __init__(self, UDID, ssc_handler:Union[str,iCertificateHandler] , serverAddress=None,beaconAddress="https://realtime.us.beacon.1.api.bluecity.ai/",subscriptions=(Realtime_subscriber.BCTWSConnection.subscriptionOption.FRAME,), cacheSize=400,singleton=False,TLS=False):
        """
        You can use this class to communicate with realtime api using Service Specific Certificates (SSC)

        Args: 
            UDID (str): Unique device ID of the desired edgebox 
            ssc_handler (Union[str,iCertificateHandler]): If you pass a certificateHandler, module renews the certificate automatically, otherwise it just uses the ssc for authentication as long as it's valid.
            serverAddress (str): Address of the realtime server. Set the address to override beacon's routing
            beaconAddress (str): Address of the beacon (load balancer)
            subscriptions (list<Realtime_subscriber.BCTWSConnection.subscriptionOption>): Categories that you want to receive data 
            cacheSize (int): Number of hyper parameters (frames) that will be cached for service. Default is 400,
            singleton (bool): Set this variable to True if you intend to receive data packaed as a hyper parameter. Otherwise you would need to receive each category (phase,frame,loop) separately 
        """
        self.isRolloverEnabled = False
        if isinstance(ssc_handler,iCertificateHandler):
            self.isRolloverEnabled = True
        
        self.isSSCHandlerProvided = self.isRolloverEnabled

        self.ssc= ssc_handler
        super().__init__( UDID, "", serverAddress=serverAddress,beaconAddress=beaconAddress,subscriptions=subscriptions, cacheSize=cacheSize,singleton=singleton,TLS=TLS)
    
    def __rollover(self):

        try:
            self.ssc:iCertificateHandler
            ssc = self.ssc.load("realtime")
            certificate_b64,_ = ssc.split(".")
            certificate_bytes = urlsafe_b64decode(certificate_b64)
            certificate = json.loads(certificate_bytes)
            if datetime.datetime.utcnow() > datetime.timedelta(days=30) + datetime.datetime.fromtimestamp(certificate["exp"]):
                # needs to be rollovered

                self.logger.info("Rollover process for SSC started")
                header = { 'AUTHORIZATION':ssc}
                resp = requests.post("https://core.api.bluecity.ai/s/auth/ssc/rollover/",headers=header)
                if resp.status_code ==200:
                    certificates_new = resp.json()

                    for name,ssc_value in certificates_new["SSCs"]:
                        self.ssc.save(name,ssc_value)
                    
                    self.logger.info("SSC rollovered successfully")
                else:
                    self.logger.warning(f"SSC rollover failed with status of {resp.status_code}")

        except Exception as ex:
            self.logger.error(f"An error happened in the rollover process\n {str(ex)}")

    def connect_secure(self):
        while True:
            try:
                self.logger.info("connecting to realtime server")
                if self.askBeacon:
                    self.getCredentials_beacon()
                
                if self.isRolloverEnabled:
                    self.__rollover()

                if self.isSSCHandlerProvided:
                    header = create_auth_header_grpc_skipChallenge(self.ssc.load("realtime")) # load the ssc using handler
                else:
                    header = create_auth_header_grpc_skipChallenge(self.ssc) # just uses the ssc

                call_credentials = grpc.metadata_call_credentials(Sub_serviceAuth_SSC(self.UDID,header),"subAuth")
                channel_credential = grpc.ssl_channel_credentials(self.crt)
                composite_credentials= grpc.composite_channel_credentials(channel_credential,call_credentials)
                with grpc.secure_channel('{}'.format(self.serverAdd), composite_credentials) as channel:
                    stub = realtime_subscriber_pb2_grpc.SubscriberStub(channel)
                    self.__subscribe(stub)
            except Exception as ex:
                if self.askBeacon:
                    self.serverAdd=None
                self.logger.critical(str(ex))
                time.sleep(10)    
    
    def connect_insecure(self):
        while True:
            try:
                self.logger.info("connecting to realtime server")
                if self.askBeacon:
                    self.getCredentials_beacon()
                    
                with grpc.insecure_channel(self.serverAdd) as channel:

                    if self.isRolloverEnabled:
                        self.__rollover()

                    if self.isSSCHandlerProvided:
                        header = create_auth_header_grpc_skipChallenge(self.ssc.load("realtime")) # load the ssc using handler
                    else:
                        header = create_auth_header_grpc_skipChallenge(self.ssc) # just uses the ssc

                    header_names=[x for x,y in header]
                    header_values = [y for x,y in header]

                    header_adder_interceptor = header_manipulator_client_interceptor.header_adder_interceptor(['bct-udid',"type"]+header_names, [self.UDID,"5"]+header_values)
                    intercept_channel = grpc.intercept_channel(channel,header_adder_interceptor)

                    stub = realtime_subscriber_pb2_grpc.SubscriberStub(intercept_channel)

                    # threading.Thread(target=self.ping,args=[stub]).start()
                    self.__subscribe(stub)
            except: 
                if self.askBeacon:
                    self.serverAdd=None
                self.logger.error("Connection to the server is lost. Retry in 5 seconds")
                time.sleep(10)           


