import pickle
import time

class ArchiveReader:
    def __init__(self,file="output",fps=10,*args,**kwargs):
        if file:
            self.file = file
            self.objs = self.__deserialize()
            self.fps=fps

        else:
            raise Exception("no file is provided")
            
    def __deserialize(self):
        with open(self.file,'rb') as file:
            data = file.read()
            objs = data.split(b"||=======||")

            for obj in objs:
                if obj:
                    obj = pickle.loads(obj)
                    yield obj

    def get_hyperparameter(self):
        time.sleep(1/self.fps)
        return next(self.objs)

