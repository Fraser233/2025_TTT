import pytest
from certficiate_handler import SSC_Certificate_Handler
import os
import shutil

def test_init():
    assert 1==1

def test_root_folder_creation():
    try:
        if os.path.exists("test/test/test"):
            assert False

        SSC_Certificate_Handler("test/test/test")
        if not os.path.exists("test/test/test"):
            assert False
        else:
            shutil.rmtree("test")
            assert True
    except: 
        assert False

