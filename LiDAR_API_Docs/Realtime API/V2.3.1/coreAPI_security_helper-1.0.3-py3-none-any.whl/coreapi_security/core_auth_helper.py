"""
This module boundles the functionalities that are needed for Authentication from CoreAPI.
"""
import hashlib
import requests
import secrets
from base64 import urlsafe_b64encode
from coreapi_security.certficiate_handler import SSC_Certificate_Handler,iCertificateHandler
import datetime
from coreapi_security.keys_handler import CoreAPI_keyHandler_eds,iKeyHandler

def request_ssc(UDID:str,key_handler:iKeyHandler,ssc_handler:iCertificateHandler,endpoint) -> bool :
    """
    Sends a request message to the CoreAPI server and receives SSCs. 

    Args:
        UDID (str): UDID of the senosr.
        keyHandler (iKeyHandler): An object of iKeyHandler. This object signs the required challenges. 
        ssc_handler (iCertificateHandler): An object of iCertificateHandler. This object should handles the actions requried for saving certificates.
        endpoint (str): Authentication server (CoreAPI) address.

    Returns:
        Status of the operation
    """
    try:
        time_ = datetime.datetime.utcnow().isoformat(timespec='microseconds') # utc time iso format

        # challenge creation. A challenge consists of a rand 32 bytes str with the time of the chanllegne compose
        challenge = secrets.token_urlsafe(32)
        msg = UDID+"|"+challenge+"|"+time_
        msg_bytes = msg.encode()
        msg_hashed = hashlib.sha256(msg_bytes).digest()

        # creating challenge signitarue 
        challenge_signed= key_handler.sign(msg_hashed)
        challenge_signed_b64 = urlsafe_b64encode(challenge_signed)

        data = {
            "UDID":UDID,
            "time": time_,
            "pkey": urlsafe_b64encode(key_handler.publicKey),
            "challenge": challenge , # raw random number
            "challenge_sign":challenge_signed_b64 # signed challenge
        }   

        # communicating with authentication server
        res= requests.post(endpoint,data=data)
        if res.status_code ==200:
            sscs= res.json()
            # storing SSCs using ssc_handler
            for ssc_name,ssc_content in sscs["SSCs"].items():
                ssc_handler.save(ssc_name,ssc_content)
            return True
        else:
            return False
    except Exception as ex:
        print (ex)
        return False

def create_auth_header_http(ssc:str,key_handler:iKeyHandler ) -> dict:
    """
    This helper function creates abstract header for HTTP Requests. The header consists of challenge, challenge-time, challenge-rand and ssc (AUTHORIZATION)
    Args:
        ssc (str): raw base64 format of a ssc.
        key_handler (iKeyHandler): an object of a keyhandler class. 
    
    Returns:
        a header as a dictionary

    """

    # challenge creation
    time_now = datetime.datetime.utcnow().isoformat(timespec='microseconds')
    rand = secrets.token_urlsafe(32) # create a 32 bytes challenge
    challenge = time_now + "|"+rand
    challenge_hashed= hashlib.sha256(challenge.encode()).digest()

    # create a signature based on challenge variables.
    challenge_signed = key_handler.sign(challenge_hashed)
    challenge_signed_b64 = urlsafe_b64encode(challenge_signed)
    challenge_combined = time_now + "."+ rand+"."+challenge_signed_b64
    header = {
        'CHALLENGE':challenge_combined,
        'AUTHORIZATION':ssc
    }
    
    return header
    
def create_auth_header_grpc(ssc:str,key_handler:iKeyHandler ) -> dict:
    """
    This helper function creates abstract header for grpc requests. The header consists of challenge, challenge-time, challenge-rand and ssc (AUTHORIZATION)
    Args:
        ssc (str): raw base64 format of a ssc.
        key_handler (iKeyHandler): an object of a keyhandler class. 
    
    Returns:
        a header as a dictionary

    """

    # challenge creation
    time_now = datetime.datetime.utcnow().isoformat(timespec='microseconds')
    rand = secrets.token_urlsafe(32) # create a 32 bytes challenge
    challenge = time_now + "|"+rand
    challenge_hashed= hashlib.sha256(challenge.encode()).digest()

    # create a signature based on challenge variables.
    challenge_signed = key_handler.sign(challenge_hashed)
    challenge_signed_b64 = urlsafe_b64encode(challenge_signed)

    header = [
        ('challenge',challenge_signed_b64),
        ('challenge_rand',rand),
        ('challenge_time',time_now),
        ('token',ssc)
    ]
    return header


def create_auth_header_grpc_skipChallenge(ssc:str) -> dict:
    """
    This helper function creates abstract header for grpc requests without creating a challenge. The header contains the ssc (AUTHORIZATION).
    Args:
        ssc (str): raw base64 format of a ssc.    
    Returns:
        a header as a dictionary

    """
    header = [
        ('token',ssc)
    ]
    return header


