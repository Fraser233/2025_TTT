"""
This module contains classes that can be used for storing and loading different type of certificates. 
"""

import os
import datetime
import shutil
from abc import ABC, abstractmethod


# ─── Exception Classes ────────────────────────────────────────────────────────
class SSC_Certificate_Save_Failed (Exception):
    """
    Custom exception class for SSC certificates. 
    """
    def __str__(self) -> str:
        return "Failed to store the certificate"

class SSC_Certificate_Load_Failed (Exception):
    """
    Custom exception class for SSC certificates. 
    """
    def __str__(self) -> str:
        return "Failed to load the certificate"

class SSC_Certificate_Not_Exists (Exception):
    def __str__(self) -> str:
        return "Certificate does not exist"
# ──────────────────────────────────────────────────────────────────────────────


class iCertificateHandler(ABC):
    """
    base class for certificate handlers
    """
    @abstractmethod
    def __init__(self,UDID,mainDirectory):...

    @abstractmethod
    def save(self,name,content):...

    @abstractmethod
    def load(self,name):...

    @abstractmethod
    def list(self):...

class SSC_Certificate_Handler(iCertificateHandler):
    """
    Handler class to store and load SSC certificates. 
    """
    def __init__(self,UDID,mainDirectory="/etc/bct/keys/") -> None:
        """
        Handler class to store and load SSC certificates.

        Args:
            mainDirectory (str): the root directory for the SSC certificates. 
            test (str): adad
        """
        # if not os.path.exists(mainDirectory):
        self.mainDirectory = mainDirectory.rstrip("/")+"/"+UDID
        os.makedirs(self.mainDirectory,exist_ok=True)
        

    def save(self,ssc_name,ssc_content):
        """
        This fuction saves a certificate. It also creates required directories. Received certificate will be saved 
        in a directoy labeld as current time. Then, a sym link to it would be moved to "Current" folder atomically. 
        This atomic movements can be helpful for detecting changes in the filesystem based "change listeners".

        Args: 
            ssc_name (str): Name of the ssc. 
            ssc_content (str): Content of the ssc
        """
        try:

            # checks the existence of a root directory for the ssc_name 
            service_directory = self.mainDirectory + "/"+ssc_name
            service_directory_current = service_directory+"/"+"current"
            if not os.path.exists(service_directory):
                # replace the keys atomically
                os.makedirs(service_directory)
                os.makedirs(service_directory_current)

            # folder name 
            date_time_str = datetime.datetime.strftime( datetime.datetime.now(),"%Y_%m_%d_%H_%M_%S")
            service_directory_update = service_directory+"/"+date_time_str
            os.makedirs(service_directory_update,exist_ok=True)
            
            # write the ssc 
            with open(service_directory_update+"/ssc.pem","w") as file:
                file.write(ssc_content)

            # Two steps process: 1- sym links the stored ssc to a file. Move the link file to the current folder as the ssc_current file 
            os.symlink(service_directory_update+"/ssc.pem",service_directory_update+"/.ssc_linked.pem")
            shutil.move(service_directory_update+"/.ssc_linked.pem",service_directory_current+"/ssc_current.pem")
            
        except Exception as ex:
            raise SSC_Certificate_Save_Failed

    def load(self,ssc_name) ->str:
        """
        Loads the certificate for a service.

        Args:
            ssc_name (str): service name
        """
        service_directory_crrent = self.mainDirectory + "/"+ssc_name +"/current/ssc_current.pem"
        if not os.path.exists(service_directory_crrent):
            raise SSC_Certificate_Not_Exists

        try:
            with open(service_directory_crrent,"r") as file:
                return file.read()

        except:
            raise SSC_Certificate_Load_Failed

    def list(self):
        """
        It would list out the sscs that are stored for the UDID
        """
        # for root,directory,file in os.walk(self.mainDirectory, topdown=False):
        directories = list(filter(lambda x: os.path.isdir(os.path.join(self.mainDirectory, x)), os.listdir(self.mainDirectory)))
        return directories


if __name__ =="__main__":
    certificate_handler = SSC_Certificate_Handler("test","/home/mo/BCTServices/Security_Helper/keys/")
    # certificate_handler.save_SSC("test","hello")
    print (certificate_handler.load("core"))