"""
This module encaplsulates functionalities of using a pair of key for edgebox authentication.  
"""

from abc import ABC, abstractmethod
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey,Ed25519PublicKey
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey,RSAPublicKey
import os
from base64 import urlsafe_b64decode


class KeyNotExistsException(Exception):
    def __str__(self) -> str:
        return "key does not exist"

class KeySignFailedException(Exception):
    def __str__(self) -> str:
        return "failed to sign the data"

class KeyVerificationFailed(Exception):
    def __str__(self) -> str:
        return "verification failed"

class iKeyHandler(ABC):
    """
    Interface for key handlers. Any key handlers should implement at least the defined functions in this interface. 
    """

    @abstractmethod
    def __init__(self,key_directory,type) -> None:
        super().__init__()

    @property
    @abstractmethod
    def publicKey(self) -> bytes:...

    @abstractmethod
    def sign(self,data:bytes) -> bytes:...

    @abstractmethod
    def verify(self,signitarue:bytes,data:bytes) -> bool:...

    @abstractmethod
    def refresh(self): ...


class CoreAPI_keyHandler_eds (iKeyHandler):
    """
    Handles keys that are generated from CoreAPI. This class supports eds25519 keys. 
    """

    def __init__(self, UDID,key_directory="/etc/bct/keys/") -> None:
        """
        Handles keys that are generated from CoreAPI. This class supports eds25519 keys. 

        Args:
            key_directory (str): the root directory of keys. The class looks for private.pem and public.pem in the root directory. 
        """
        self.key_directory = key_directory.rstrip("/")+"/"+UDID+"/"
        
        self.__load()

        
    
    def __load(self):
        if not os.path.exists(self.key_directory.rstrip("/")+"/private.pem") or not os.path.exists(self.key_directory.rstrip("/")+"/public.pem"):
            raise KeyNotExistsException()

        with open(self.key_directory.rstrip("/")+"/private.pem","rb") as file:
            self._private_key= Ed25519PrivateKey.from_private_bytes(urlsafe_b64decode( file.read()))
        
        with open(self.key_directory.rstrip("/")+"/public.pem","rb") as file:
            self._public_key_bytes= urlsafe_b64decode(file.read())
            self._public_key = Ed25519PublicKey.from_public_bytes(self._public_key_bytes) # to be shared with the property
        


    @property
    def publicKey(self) -> bytes:
        return self._public_key_bytes
    
    def sign(self, data: bytes) -> bytes:  
        """
        Signs data with the private key.

        Args:
            data (bytes): Data you want to be signed. 
        
        Returns:
            signed data
        """     
        try:
            return self._private_key.sign(data)
        except:
            raise KeySignFailedException()

    def verify(self, signitarue: bytes, data: bytes) -> bool:
        """
        Verifies signitarues using public key.

        Returns: 
            True if the signitaue is valid, False otherwise. 
        """
        try:
            self._public_key.verify(signitarue,data)
            return True
        except:
            return False

    def refresh(self):
        self.__load()

if __name__=="__main__":
    
    CoreAPI_keyHandler_eds()